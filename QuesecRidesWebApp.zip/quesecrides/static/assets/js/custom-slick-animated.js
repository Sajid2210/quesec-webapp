 /**=====================
     Custom Slick Animated js
==========================**/
 $('.slider-animate').slick({
     autoplay: true,
     speed: 1800,
     lazyLoad: 'progressive',
     fade: true,
     dots: true,
 }).slickAnimation();